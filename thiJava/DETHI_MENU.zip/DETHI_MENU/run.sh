#!/bin/sh
cd "$(dirname "$0")" || exit 1
javac -encoding UTF-8 *.java || exit 1
exec java -Dfile.encoding=UTF-8 -cp . Menu
