import java.io.File;
import java.io.FileInputStream;
import java.io.FileDescriptor;
import java.io.IOException;

public class Menu {
    private static final String[] LABS = {
        "Lab01", "Lab02", "Lab03", "Lab04", "Lab05",
        "Lab06", "Lab07", "Lab08", "Lab09"
    };

    private static final String[] DESCRIPTIONS = {
        "Tao BST va xuat sinh vien theo ID",
        "Tinh tong so sinh vien va diem trung binh",
        "Tinh ti le sinh vien theo xep loai",
        "Tim sinh vien nam co diem cao nhat va thap nhat",
        "Tim sinh vien theo ID",
        "Xoa sinh vien theo ID",
        "Tach danh sach sinh vien dau va rot",
        "Sap xep danh sach dau va rot theo diem",
        "Sap xep danh sach dau va rot theo ten"
    };

    private static final FileInputStream input = new FileInputStream(FileDescriptor.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n========== MENU LAB JAVA ==========");
            for (int i = 0; i < LABS.length; i++) {
                System.out.println((i + 1) + ". " + DESCRIPTIONS[i]);
            }
            System.out.println("0. Thoat");

            String choice = readLine("Chon bai (0-9): ");
            if (choice == null || choice.equals("0")) {
                System.out.println("Da thoat chuong trinh.");
                break;
            }

            int number;
            try {
                number = Integer.parseInt(choice);
            } catch (NumberFormatException e) {
                System.out.println("Lua chon khong hop le. Vui long nhap tu 0 den 9.");
                continue;
            }

            if (number < 1 || number > 9) {
                System.out.println("Lua chon khong hop le. Vui long nhap tu 0 den 9.");
                continue;
            }

            runLab(LABS[number - 1]);
        }
    }

    private static String readLine(String prompt) {
        System.out.print(prompt);
        System.out.flush();
        StringBuilder line = new StringBuilder();
        boolean readAny = false;

        try {
            while (true) {
                int ch = input.read();
                if (ch == -1) {
                    if (!readAny) return null;
                    break;
                }
                readAny = true;
                if (ch == '\n') break;
                if (ch != '\r') line.append((char) ch);
            }
        } catch (IOException e) {
            System.out.println("Khong doc duoc lua chon: " + e.getMessage());
            return null;
        }

        return line.toString().trim();
    }

    private static void runLab(String className) {
        String java = System.getProperty("java.home") + File.separator + "bin" + File.separator + "java";
        if (System.getProperty("os.name").toLowerCase().contains("win")) {
            java += ".exe";
        }

        try {
            ProcessBuilder builder = new ProcessBuilder(
                java, "-Dfile.encoding=UTF-8", "-cp", System.getProperty("java.class.path"), className
            );
            builder.inheritIO();
            int result = builder.start().waitFor();
            if (result != 0) {
                System.out.println("Bai " + className + " ket thuc voi ma loi: " + result);
            }
        } catch (IOException e) {
            System.out.println("Khong the mo " + className + ": " + e.getMessage());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            System.out.println("Chuong trinh bi ngat khi dang chay " + className + ".");
        }
    }
}
