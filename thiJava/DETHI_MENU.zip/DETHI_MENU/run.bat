@echo off
cd /d "%~dp0"
chcp 65001 >nul
echo Dang bien dich cac bai lab...
javac -encoding UTF-8 *.java
if errorlevel 1 goto loi
echo.
java -Dfile.encoding=UTF-8 -cp . Menu
if errorlevel 1 goto loi
echo.
goto ketthuc
:loi
echo Co loi khi bien dich hoac chay chuong trinh.
:ketthuc
pause
